This function generator is created by Da_Noobiest_Noob with the inspiration from TheAfroOfDoom

Running the program, just follow the instructions and input values for the names and lengths of the music you want
looped. This program will generate

1) A sounds.json that the user will put in their resource pack

2) A datapack that users will put in their datapacks, or to combine with their own. I don't care what you do with it
as long as my credit remains.

3) A README.txt that details the instructions below.

The program should be easy to use, just press "cancel" to exit the program at any point. Please report bugs to
https://github.com/Da-Noobiest-Noob/Minecraft-Music-Function-Creator


~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

There are three things the user needs to do after using this program.

1) The user must put the sounds.json on their desktop in the correct folder of their resource pack,
   or combine this sounds.json with the previous one

2) The user must put all music they wished to be looped in the following file location of their resourcepack
   "assets\minecraft\sounds\custom_music\<place music files here>" 
   If the music is not in the right folder, the output log will report that the file cannot be found.

3) The user must report any and all bugs at this website, 
  https://github.com/Da-Noobiest-Noob/Minecraft-Music-Function-Creator

Thank you for using my generator, I hope it helps with whatever project you are working on.

To contact me about minecraft, my discord username in the MCC discord is Agoodoldchap#7068